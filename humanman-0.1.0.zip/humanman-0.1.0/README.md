For those who wanna be a human and are an alien living on Mars one and a half AU away.
Here it is.
The cellifier.
The digestor.
The organifier.
The DNAifier.

Regards: The Curious Coder