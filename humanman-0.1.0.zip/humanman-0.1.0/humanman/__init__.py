"""
Humanman - yes that is a tongue twister but dont talk about it
Includes:
    Cells - why buy a microscope?
    Digestion - WHAT THE F**K IS A STOMACH ACHE
    DNA - yes, that thing that builds you
    Organs - please do not take one out
    Nerves - why do scientists say nerve endings but not nerve startings
    
Regards: The Curious Coder
"""
from .Cell import Cell
from .digest import digest
from .organs import organs
from .DNA import DNA
from .nerves import nerves